plugins { id("com.android.application") }

android {
    namespace = "com.meuautonomo.app"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.meuautonomo.app"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
    }
}
